function multipleWithReduce(numbers) {
  return numbers.reduce((product, number) => product * number, 1);
}
